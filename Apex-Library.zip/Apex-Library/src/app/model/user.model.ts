export class User {
    firstName: string;
    lastName: string;
    email: string;
    book: string;
    role: string;
    dob: string;
    country: string;
    state: string;
    city: string;
}