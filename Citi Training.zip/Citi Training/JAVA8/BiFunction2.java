//https://www.concretepage.com/java/jdk-8/java-8-biconsumer-bifunction-bipredicate-example
//https://www.javatpoint.com/java-8-stream
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.ToIntBiFunction;
public class BiFunction2 {
    public static void main(String[] args) {
        Function<Integer, String> biFunction = (num1) -> "Result:" +(num1);
        System.out.println(biFunction.apply(20));
    	//ToIntBiFunction<Integer,Integer> biFunction = (num1, num2) -> (num1 + num2);
    	//biFunction.applyAsInt(56,67);
    }    
} 