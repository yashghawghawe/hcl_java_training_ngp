
import java.util.function.BiFunction;
public class BiFunction4 {
    public static void main(String[] args) {
        BiFunction<String, String, Integer> biFunction = (num1, num2) -> {return (num1.length() + num2.length());};
        System.out.println(biFunction.apply("abc","bcd"));
    }    
}