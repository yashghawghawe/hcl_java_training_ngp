import java.util.function.Consumer;
//https://www.concretepage.com/java/jdk-8/java-8-biconsumer-bifunction-bipredicate-example
//https://www.javatpoint.com/custom-annotation
//The Consumer Interface accepts a single argument and does not return any result.
public class ConsumerDemo {  
	static void display(String str)
	{
		System.out.println(str);
	}
	public static void main(String[] args) {
	Consumer<String> consumer1=str->System.out.println(str);
	consumer1.accept("Hello");
	}
}
   /* static void printMessage(String name){  
        System.out.println("Hello "+name);  
    }  
    static void printValue(int val){  
        System.out.println(val);  
    }  
    public static void main(String[] args) {  
        // Referring method to String type Consumer interface   
        Consumer<String> consumer1 = ConsumerDemo::printMessage;  
        consumer1.accept("John");   // Calling Consumer method  
        // Referring method to Integer type Consumer interface  
        Consumer<Integer> consumer2 = ConsumerDemo::printValue;  
        consumer2.accept(12);   // Calling Consumer method  
    }  */*/
