


interface Vehicle {
	
   static void blowHorn() {
      System.out.println("Blowing horn!!!");
   }
}

interface FourWheeler {

	  static void blowHorn() {
	      System.out.println("Blowing horn!!!");
	   }
}

class Car implements Vehicle,FourWheeler {

   public void print() {
    
      System.out.println("I am a car!");
   }
}
public class INterfaceDemo {

	   public static void main(String args[]) {
	      Vehicle vehicle = new Car();//upcasting
	      Vehicle.blowHorn();
	      FourWheeler.blowHorn();
	   }
	}
