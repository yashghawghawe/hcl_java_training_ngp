///import java.io.PrintStream;

//https://beginnersbook.com/2017/10/java-8-interface-changes-default-method-and-static-method/
//https://www.geeksforgeeks.org/default-methods-java/
//@FunctionalInterface
interface TestInterface3
{ 
    // abstract method 
    public void square(int a); 
       // default method 
    default void show() 
    { 
    
      System.out.println("Parent Method Executed"); 
    } 
    default void show1() 
    { 
    
      System.out.println("Parent Method Executed"); 
    } 
} 
  
class InterfaceExample implements TestInterface3
{ 
    // implementation of square abstract method 
    public void square(int a) 
    { 
        System.out.println(a*a); 
    } 
 /*static void show() 
   { 
     System.out.println("Child Method Executed"); 
    } */
  
    public static void main(String args[]) 
    { 
    	InterfaceExample d = new InterfaceExample(); 
        d.square(4); 
        d.show(); 
    } 
} 