//https://java2blog.com/system-out-println-java/
import java.util.List;
import java.util.StringJoiner;
import java.util.ArrayList;
import java.util.Iterator;
public class MethodReference1 {
   public static void main(String args[]) {
	   //StringJoiner sj=new StringJoiner("Kumar");
	     List<String> names = new ArrayList<>();
       names.add("Ramesh");
     names.add("Naresh");
     names.add("Kalpesh");
   
     names.forEach(System.out::println);
  //  names.forEach(name->System.out.println(name));
   
 //   names.forEach(System.out.println(Student::name));
     // 
	//;
	
      // names.stream().map(p->p+" Kumar").forEach(System.out::println);
       //names.forEach((name+sj)->System.out::println);
		
   }
}