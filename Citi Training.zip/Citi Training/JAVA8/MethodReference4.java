
import java.util.List;
import java.util.ArrayList;
public class MethodReference4 {
   public static void main(String[] args) {
      List<String> fruits = new ArrayList<String>();
      fruits.add("Apple");
      fruits.add("Orange");
      fruits.add("Banana");
      fruits.add("Pear"); 
      fruits.add("Mango");
     // fruits.forEach(str->System.out.println(str));
      fruits.forEach(System.out::println);
     // fruits.forEach(System.out::println);
      //lambda expression in forEach Method 
      //fruits.forEach(str->System.out.println(str));
      //fruits.forEach(System.out::println);
   }
}