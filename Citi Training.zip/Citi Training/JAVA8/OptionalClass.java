import java.util.Optional;

public class OptionalClass{   
    public static void main(String[] args) {   
        String[] words = new String[10];   
         words[5]="Java";
       Optional checknull= Optional.ofNullable(words[5]);
       if(checknull.isPresent())
       {
        String word = words[5].toLowerCase(); 
        System.out.println(word);
       }
       else
    	   System.out.println("null value");
    }   
} 