
import java.util.Optional;

public class OptionalClass1 {
	public static void main(String[] args) {
	//	String[] words = new String[10];
		 String[] str = new String[10];        
	      //  str[5] = "JAVA OPTIONAL CLASS EXAMPLE"; 
	        System.out.println(Optional.ofNullable(str[5]).orElse("Null value"));  
		//System.out.println(Optional.ofNullable(words[5]).orElse("Null"));
		/*
		 * if (checkNull.isPresent()) { String word = words[5].toLowerCase();
		 * System.out.print(word); } else System.out.println("word is null");
		 */

	}
}

/*    */