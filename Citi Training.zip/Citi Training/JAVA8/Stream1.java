import java.util.*;
import java.util.stream.Collectors;  
class Product{  
    int id;  
    String name;  
    float price;  
    public Product(int id, String name, float price) {  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }  
}  
public class Stream1 {  
    public static void main(String[] args) {  
    	
    	 
    	        System.out.println("Using forEach()");
    	        String str = "Yashwant Chavan";
    	        str.chars().forEach(n -> System.out.print((char) n));
    	 
    	        System.out.println("\n\nUsing parallel() + forEach()");
    	        str.chars().parallel().forEach(n -> System.out.print((char) n));
    	 
    	        System.out.println("\n\nUsing parallel() + forEachOrdered()");
    	        str.chars().parallel().forEachOrdered(n -> System.out.print((char) n));
    	   
    	/*List<Integer> list = Arrays.asList(2, 4, 6, 8, 10); 
    	list.stream()
    	    .sorted(Comparator.reverseOrder())
    	    .forEach(name->System.out.println(name));*/
       /* List<Product> productsList = new ArrayList<Product>();  
        productsList.add(new Product(1,"HP Laptop",25000f)); //1 
        productsList.add(new Product(2,"Dell Laptop",30000f));  
        productsList.add(new Product(3,"Lenevo Laptop",28000f));//2  
        productsList.add(new Product(4,"Sony Laptop",28000f)); //3 
        productsList.add(new Product(5,"Apple Laptop",90000f));  
        Set ls=productsList.stream().filter(p->p.price<30000)
        		.map(p->p.price)
        		.collect(Collectors.toSet());
       // ls.forEach(product->System.out.println(product.name+" "+product.price));
        ls.forEach(product->System.out.println(product));
        */
       /* .forEach(p->System.out.println(p.id));*/
      //  .forEach(p->System.out.println(p.name));
       /* List<Float> productPriceList = new ArrayList<Float>(); 
                for(Product product: productsList){  
          if(product.price<30000){  
                productPriceList.add(product.price);    // adding price to a productPriceList  
            }  
        }  
        System.out.println(productPriceList);   // displaying data  
*/    }  
}  