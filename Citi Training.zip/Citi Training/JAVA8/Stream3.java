
import java.util.*;
import java.util.stream.Collectors;  
class Product_Stream3{  
    int id;  
    String name;  
    float price;  
    public Product_Stream3(int id, String name, float price) {  
        this.id = id;  
        this.name = name;  
        this.price = price;  
    }  
}  
public class Stream3 {  
    public static void main(String[] args) {  
        List<Product_Stream3> productsList = new ArrayList<Product_Stream3>();  
        //Adding Products  
        productsList.add(new Product_Stream3(1,"HP Laptop",25000f));  
     //  productsList.add(new Product_Stream3(2,"Dell Laptop",30000f));  
       /*  productsList.add(new Product_Stream3(3,"Lenevo Laptop",28000f));  
        productsList.add(new Product_Stream3(4,"Sony Laptop",28000f));  
        productsList.add(new Product_Stream3(5,"Apple Laptop",90000f)); */ 
          /* productsList.stream()
                             .filter(product -> product.price == 25000)
                           //  .peek(p->System.out.println(p.price))
                             .map(products -> products)
                           //  .peek(p->System.out.println(p))
                            // .collect(Collectors.toList());
                             .forEach(products -> System.out.println(products)); 
          // list.forEach(products -> System.out.println(products));
*/    }  
}  