package com.yash.jdbc;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class StuDetails5 {

	public static void main(String[] args) {
		SessionFactory myFactory= new Configuration()
								  .configure("hibernate.cfg.xml")
								  .addAnnotatedClass(Student5.class)
								  .buildSessionFactory();
		Session mySession=myFactory.getCurrentSession();
		try {
			//create  student object
			Student5 newstu=new Student5("Yash","Ghawghawe","yashghwaghave@gmail.com");
			//Begin Transaction
			mySession.beginTransaction();
			//save student data
			mySession.save(newstu);
			//commit changes
			mySession.getTransaction().commit();
		} finally {
			myFactory.close();
		}
		
	}

}
