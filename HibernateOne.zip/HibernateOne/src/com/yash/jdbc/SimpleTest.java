package com.yash.jdbc;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class SimpleTest {
	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Student student=new Student();
		student.setName("Yash");
		student.setDegree("Mechanical");
		student.setRoll("121");
		student.setPhone("8983568315");
		
		Transaction tx=session.beginTransaction();
		session.save(student);
		System.out.println("Object Saved Successfully.....!!");
		tx.commit();
		session.close();
		factory.close();
	}
}
